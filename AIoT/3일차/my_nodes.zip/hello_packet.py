# from router_lab import NodeCustomBase


# class SimplePacket:
#     def __init__(self, src: str, data: bytes):  #패킷 클래스를 하나 만든다
#         self.src = src
#         self.data = data    
    
#     def to_bytes(self) -> bytes:  #바이트로 만드는거
#         return b"simple\n" + self.src.encode() + b"\n" + self.data    
#         # 필드를 나누려면\n 쓰고 소스 ip가 스트링이니까 바이트로 인코딩하고, 
    
#     @classmethod
#     def from_bytes(cls, data: bytes) -> "SimplePacket": #바이트에서 소스랑 데이터를 뽑아내는거
#         lines = data.split(b"\n") # \n 로 나누고 리스트 형태로 저장한다
#         src = lines[1].decode() #소스가 들어감, 이거 바이트였으니까 다시 스트링으로 바꿔준다
#         data = lines[2] # 데이터가 들어감
#         return cls(src, data)
    
    
#     class HelloPacketNodeImpl(NodeCustomBase):
#         async def every_1s(self):
#             self.timer += 1
#             if self.timer % 10 == 1: #10초에 한 번씩 하는건디
#                 await self.broadcast(SimplePacket(self.ip, b"Hello!").to_bytes())    #이건 패킷에 감싸서 보내는거
                
        
#         async def main(self):
#             self.timer = 0    
        
#         async def on_recv(self, src_1hop: str, data: bytes): 
#             pkt = SimplePacket.from_bytes(data)
#             self.log.info(f"Received from {src_1hop}: {pkt.data}")
#             if data == b"Hello!":
#                 await self.unicast(
#                     src_1hop, SimplePacket(src_1hop, b"Hello, " + pkt.src.encode() + b"!").to_bytes()
#                 )  # 답장을 해주는거 근데 답장할 때도 패킷에 감싸서 보낸다. 

from router_lab import NodeCustomBase


class SimplePacket:
    def __init__(self, src: str, data: bytes):
        self.src = src
        self.data = data

    def to_bytes(self) -> bytes:
        return b"simple\n" + self.src.encode() + b"\n" + self.data

    @classmethod
    def from_bytes(cls, data: bytes) -> "SimplePacket":
        lines = data.split(b"\n")
        src = lines[1].decode()
        data = lines[2]
        return cls(src, data)


class HelloPacketNodeImpl(NodeCustomBase):
    async def every_1s(self):
        self.timer += 1
        if self.timer % 10 == 1:
            await self.broadcast(SimplePacket(self.ip, b"Hello!").to_bytes())

    async def main(self):
        self.timer = 0

    async def on_recv(self, src_1hop: str, data: bytes):
        pkt = SimplePacket.from_bytes(data)
        self.log.info(f"Received from {src_1hop}: {pkt.data}")
        if data == b"Hello!":
            await self.unicast(
                src_1hop, SimplePacket(src_1hop, b"Hello, " + pkt.src.encode() + b"!").to_bytes()
            )