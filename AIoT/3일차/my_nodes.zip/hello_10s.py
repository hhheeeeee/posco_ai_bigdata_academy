from router_lab import NodeCustomBase

class Hello10NodeImpl(NodeCustomBase):
    async def every_1s(self): 
        self.timer += 1 #1초에 한번씩 타이머를 1씩 늘린다
        if self.timer % 10 == 1: #타이머가 1, 11, 21,31..... 일 때 밑에줄 실행
            await self.broadcast(b"Hello!") # 자기 인접한 노드에 byte된 Hello!를 보낸다
    
    async def main(self):
        self.timer = 0 # 일단 타이머를 0으로 한다

    async def on_recv(self, src_1hop:str, data:bytes): #만약 다른애로부터 패킷 받으면
        self.log.info(f"Received from {src_1hop}: {data}") #어디서 받았는지 로그 해주고
        if data == b"Hello!": #만약 데이터가 헬로우면
            await self.unicast(src_1hop, b"Hello, " + src_1hop.encode() + b"!") #보낸 친구한테 unicast 첫번째 아규먼트가 데스트이므로
            # 보낸 친구한데 hello라고 답장을 하고    바이트로 데이터를 보내야 되니까 인코딩해주는거

