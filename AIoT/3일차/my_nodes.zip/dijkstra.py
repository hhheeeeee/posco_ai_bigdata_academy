import time

from router_lab import NodeCustomBase, is_valid_ip


class DijkstraRoutingPacket:
    def __init__(self, src: str,link_states: dict[str, float]):
        self.src = src
        self.link_states: dict[str, float] = link_states

    # 정보를 바이트로
    def to_bytes(self) -> bytes:
        return (
            b"routing\n"
            + self.src.encode()
            + b"\n"
            + b"\n".join(f"{dst} {cost}".encode() for dst, cost in self.link_states.items())
        )

    # 바이트로 된 정보들을 line에 저장
    @classmethod
    def from_bytes(cls, data: bytes) -> "DijkstraRoutingPacket":
        lines = data.split(b"\n")
        src = lines[1].decode()
        link_states = {}
        for line in lines[2:]:
            if not line:
                continue
            dst, cost = line.decode().split()
            # error handling error로 생성된 이상한 ip가 없도록
            assert is_valid_ip(dst), "Invalid IP, maybe bit corruption!"
            link_states[dst] = float(cost)
        return cls(src,link_states)


class DataPacket:
    def __init__(self, src: str, dst: str, hop: int, data: bytes):
        self.src = src
        self.dst = dst
        self.hop = hop
        self.data = data

    def to_bytes(self) -> bytes:
        return (
            b"data\n"
            + self.src.encode()
            + b"\n"
            + self.dst.encode()
            + b"\n"
            + str(self.hop).encode()
            + b"\n"
            + self.data
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "DataPacket":
        lines = data.split(b"\n")
        src = lines[1].decode()
        dst = lines[2].decode()
        hop = int(lines[3].decode())
        data = lines[4]
        return cls(src, dst, hop, data)

class NullPacket:
    def __init__(self, is_ack: bool, timestamp: float):
            self.is_ack = is_ack
            self.timestamp = timestamp

    def to_bytes(self) -> bytes:
        return b"null\n" + str(int(self.is_ack)).encode() + b"\n" + str(self.timestamp).encode()

    @classmethod
    def from_bytes(cls, data: bytes) -> "NullPacket":
        lines = data.split(b"\n")
        is_ack = bool(int(lines[1].decode()))
        timestamp = float(lines[2].decode())
        return cls(is_ack, timestamp)

class DijkstraNodeImpl(NodeCustomBase):
    def run_dijkstra(self):
        self.log.info(f"all_link_states ({len(self.all_link_states)}) = {self.all_link_states}")

        D: dict[str, float] = {}
        S: set[str] = set()
        S.add(self.ip)
        for node_ip in self.all_link_states:
                if node_ip in self.my_link_states:
                    D[node_ip] = self.my_link_states[node_ip]
                else:
                    D[node_ip] = float("inf")
        D[self.ip] = 0
        p: dict[str, str] = {self.ip: self.ip}

        for node in self.my_link_states:
            p[node] = node

        while len(S) < len(self.all_link_states):
            min_node = None
            min_cost = float("inf")
            for node_ip in D:
                if node_ip not in S and D[node_ip] < min_cost:
                    min_node = node_ip
                    min_cost = D[node_ip]
            assert min_node is not None, "Graph is not connected!"
            S.add(min_node)
            for node_ip in self.all_link_states[min_node]:
                if node_ip not in S:
                    if(D[min_node] + self.all_link_states[min_node][node_ip]) < D[node_ip]:
                        D[node_ip] = D[min_node] + self.all_link_states[min_node][node_ip]
                        p[node_ip] = min_node
        self.routing_table = {}
        for node_ip in self.all_link_states:
            if node_ip != self.ip:
                self.routing_table[node_ip] = (p[node_ip], D[node_ip])
                self.record_table(node_ip, next_hop=p[node_ip], cost=D[node_ip])

        self.log.info("Computed Dijkstra's routing table!")
        
    async def every_1s(self):
        self.timer += 1
        if self.timer > 10 and not self.is_self_flooded:
            self.is_self_flooded = True
            self.flooding_check.append(self.ip)
            self.all_link_states[self.ip] = self.my_link_states.copy()
            await self.broadcast(DijkstraRoutingPacket(self.ip, self.my_link_states).to_bytes())
        if self.timer > 40 and not self.is_routing_table_calculated:
            self.is_routing_table_calculated = True
            self.run_dijkstra()

    async def main(self):
        self.timer = 0
        self.is_self_flooded = False
        self.is_routing_table_calculated = False
        self.routing_table: dict[str, tuple[str, float]] = {}
        self.my_link_states: dict[str, float] = {}
        self.all_link_states: dict[str, dict[str, float]] = {}
        self.flooding_check: list[str] = []
        await self.broadcast(NullPacket(False, time.time()).to_bytes())
    
    async def on_recv(self, src: str, pkt_bytes: bytes):
        if pkt_bytes.startswith(b"routing"):
            pkt = DijkstraRoutingPacket.from_bytes(pkt_bytes)
            if pkt.src not in self.flooding_check:
                self.log.info(f"Received routing table from {src}: {pkt.link_states}")
                self.all_link_states[pkt.src] = pkt.link_states
                self.flooding_check.append(pkt.src)
                await self.broadcast(pkt_bytes)
            elif pkt_bytes.startswith(b"data"):
                pkt = DataPacket.from_bytes(pkt_bytes)
                if pkt.dst == self.ip:
                    self.log.info(f"Received from {pkt.src} with {pkt.hop} hops: {pkt.data}")
                    self.record_stat(routed_hops=pkt.hop)
                else:
                    next_hop, cost = self.routing_table[pkt.dst]
                    self.log.info(f"Sending to {pkt.dst} via {next_hop} (cost : {cost})")
                    await self.unicast(
                        next_hop, DataPacket(self.ip, pkt.dst, pkt.hop +1, pkt.data).to_bytes()
                    )
            elif pkt_bytes.startswith(b"null"):
                pkt = NullPacket.from_bytes(pkt_bytes)
                if pkt.is_ack:
                    self.my_link_states[src] = time.time() - pkt.timestamp
                else:
                    await self.unicast(src, NullPacket(True, time.time()).to_bytes())
            else:
                self.log.warning(f"Unknown packet from {src}!")
        
        async def on_queue(self, dst: str, data: bytes):
            if dst in self.routing_table:
                next_hop, cost = self.routing_table[dst]
                self.log.info(f"Sending to {dst} via {next_hop} (cost : {cost})")
                await self.unicast(next_hop, DataPacket(self.ip, dst, 1, data).to_bytes())
            else:
                self.log.info(f"Cannot send to {dst} (no route!)")