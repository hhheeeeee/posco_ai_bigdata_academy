import uuid

from router_lab import NodeCustomBase

##전체 어떤 packet에서 flooding을 했으면 멀리있는 노드에게 패킷 보냄
## 본인한테 오게되면 종료


class SimpleFloodingPacket:
    def __init__(self, id: str, src: str, dst: str, data: bytes):
        self.id = id
        self.src = src
        self.dst = dst
        self.data = data

    def to_bytes(self) -> bytes:  # 바이트 형태로 저장하여 return
        return (
            b"flooding\n"
            + self.id.encode()
            + b"\n"
            + self.src.encode()
            + b"\n"
            + self.dst.encode()
            + b"\n"
            + self.data
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "SimpleFloodingPacket":  # 바이트에서 정보 뽑아내기 ,ID, source
        lines = data.split(b"\n")
        id = lines[1].decode()
        src = lines[2].decode()
        dst = lines[3].decode()
        data = lines[4]
        return cls(id, src, dst, data)


class HelloPacketNodeImp1(NodeCustomBase):
    async def every_1s(self):
        self.timer += 1
        if self.timer % 20 == 1:
            await self.broadcast(
                SimpleFloodingPacket(
                    str(uuid.uuid4())[:4], self.ip, self.get_random_ip(), b"Hello!"
                ).to_bytes()
            )

    async def main(self):
        self.timer = 0
        self.received_ids = set()

    async def on_recv(self, src_1hop: str, data: bytes):
        pkt = SimpleFloodingPacket.from_bytes(data)
        if pkt.id in self.received_ids:
            return
        if pkt.dst == self.ip:
            self.log.info(f"I'm {self.ip}, and received from {pkt.src}: {pkt.data}")
            self.received_ids.add(pkt.id)
            if pkt.data == b"Hello!":
                await self.broadcast(
                    SimpleFloodingPacket(
                        str(uuid.uuid4())[:4],
                        self.ip,
                        pkt.src,
                        b"Hello, " + pkt.src.encode() + b"!",
                    ).to_bytes()
                )
        else:
            self.received_ids.add(pkt.id)
            await self.broadcast(data)
