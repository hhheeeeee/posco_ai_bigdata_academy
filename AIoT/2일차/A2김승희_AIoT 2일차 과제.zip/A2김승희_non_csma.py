from mac.base import BaseMAC, simulation
from utils import MyLogger


logger = MyLogger() 


class NonCSMA_MAC(BaseMAC):
    def __init__(self, env, node, *args, **kwargs):
        super().__init__(env, node, *args, **kwargs)

    @simulation
    def transmit_packet(self, link, packet):
        self.tx_attempt += 1 #통신이 실패 했을 때 어쨌건 다시 보내야되는데 무한정보낼 수 없으니까 제한을 둬야함

        #통신이 실패 했을 때 어쨌거나 다시 보내야되는데 무한정 보낼 수 없으니까 제한을 둬야한다.
        if self.tx_attempt > 15: # 16번 이상 보내게 되면 통신 실패로 간주한다.
            yield self.env.timeout(0.0) # 바로 다음으로 넘어가지 않고 대기
        else:
            yield self.env.process(self.node.transmit(link, packet)) # 통신 실패하기 전까지는 계속해서 패킷을 보낸다.
    
    @simulation 
    def on_transmission_failed(self, link, packet, reason):
        yield self.env.process(self.transmit_packet(link, packet))  # 통신 실패해도 transmit_packet 메서드를 호출하여 재전송을 수행

# 거의다 실패할 것이다. 모든 노드가 ex)100개의 노드가 서로 보내려고만 하기 때문이다.
# 아무 MAC 프로토콜을 구현하지 않았기 때문이다.
# 링크 속도를 낮추거나 노드 수를 줄이면 패킷전달률이 확실히 향상될 것이다.
# 패킷레이트(1초에 몇개 보낼지) 이걸 줄여도 패킷전달률이 좀 더 올라간다
