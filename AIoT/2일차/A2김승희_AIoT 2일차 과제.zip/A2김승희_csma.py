from mac.non_csma import NonCSMA_MAC
from mac.base import simulation 
from utils import MyLogger

logger = MyLogger() 



class CSMA_MAC(NonCSMA_MAC):
    def __init__(self, env, node, *args, **kwargs):
        super().__init__(env, node, *args, **kwargs)

    @simulation
    def transmit_packet(self, link, packet):
        # 공유 매체를 확인하고 패킷을 보낸다.
        # 매체가 비어있을 때까지 대기한다.
        # 매체가 비어있으면 패킷을 보낸다.
        yield self.env.process(self.node.wait_until_idle())

        self.tx_attempt += 1 # 통신 시도 횟수 증가시킨다 (통신 실패 시 재전송을 위해)

        if self.tx_attempt > 15: # 16번 이상 보내게 되면 통신 실패로 간주한다.
            yield self.env.timeout(0.0) # 바로 다음으로 넘어가지 않고 대기
        else:
            yield self.env.process(self.node.transmit(link, packet)) # 통신 실패하기 전까지는 계속해서 패킷을 보낸다.

# no_csma보다는 조금 더 나아진 성능을 보일 것이다.
