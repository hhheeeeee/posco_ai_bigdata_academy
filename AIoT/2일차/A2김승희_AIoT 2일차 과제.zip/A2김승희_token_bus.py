from mac.base import BaseMAC, simulation


class TokenBusMAC(BaseMAC):
    RETRANSMIT_LIMIT = 16 # 패킷 재전송 제한 횟수

    def __init__(self, env, node, *args, **kwargs):
        super().__init__(env, node, *args, **kwargs) 
    
    @simulation
    def transmit_packet(self, link, packet):
        # 본인이 토큰이 있을 때 전송해야됨. 토큰 받을 때까지 기다린다
        yield self.env.process(self.node.wait_until_token_received())
        # 본인 토큰이 있을 때는 계속 패킷을 보낸다.
        yield self.env.process(super().transmit_packet(link, packet))

    @simulation 
    def on_token_expired(self):
        yield self.env.process(self.node.pass_token())  
        # 본인 토큰이 만료되면 다음 노드에게 토큰을 전달
    
# 충돌이 거의 일어나지 않게 된다!