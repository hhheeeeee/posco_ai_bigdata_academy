from mac.csma import CSMA_MAC 
from mac.base import simulation 
import numpy as np 
from utils import MyLogger

logger = MyLogger() 


class CSMA_CD_MAC(CSMA_MAC):
    def __init__(self, env, node, *args, **kwargs):
        super().__init__(env, node, *args, **kwargs)

        self.backoff = False  # 백오프 상태를 나타내는 변수

    @simulation
    def on_collision_detected(self, link, packet): # 충돌이 감지되었을 때 수행되는 함수
        if self.is_transmitting:
            yield self.env.process(self.node.stop_transmit())
            self.node.send_jamming_signal() # 현재 통신 중인 경우 통신을 중지하고 jamming signal을 보낸다
            self.backoff = True # back-off 상태로 전환한다.

    @simulation
    def on_receive_jamming_signal(self):  # 잼 신호를 수신한 경우 수행되는 함수
        if self.is_transmitting:
            yield self.env.process(self.node.stop_transmit()) # 현재 통신 중인 경우 통신을 중지한다
            self.backoff = True # back-off 상태로 전환한다


    @simulation 
    def on_transmission_failed(self, link, packet, reason):
        # 전송이 실패한 경우 backoff 해야된다
        # 만약 backoff가 진행중이라면(back-off상태라면)
        if self.backoff:
            num_slots = np.random.randint(0, 2**self.tx_attempt)
            # 백오프 슬롯 개수를 결정하기 위해 2의 제곱수를 사용, 무작위로 슬롯 수 선택
            # 백오프 슬롯 시간만큼 대기
            yield self.env.timeout(link.SLOT_TIME * num_slots)
        # 대기 후에 패킷을 다시 전송
        yield self.env.process(self.transmit_packet(link, packet))

    @simulation 
    def on_transmission_success(self, link, packet):
        # 전송이 성공한 경우 백오프할 필요가 없으므로 백오프 변수를 False로 설정
        self.backoff = False